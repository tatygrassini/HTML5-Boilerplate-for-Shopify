$(document).ready(function() {
	//Lightbox -----------------------
	$("a[rel='colorbox']").colorbox();
	//flexslider -----------------
	$('.flexslider').flexslider({
		animation: "slide",
		slideshow: "true",
		controlsContainer: ".flex-container"
	});
});


